<?php
session_start();
require_once "db.php";

// Connect separately to `ysmir_ir`
$host_ir = "localhost";
$username_ir = "ysmir_ir";  // Use correct username for `ysmir_ir`
$password_ir = "7S2h%}=w,[M+"; // Use correct password
$database_ir = "ysmir_ir";

$conn_ir = new mysqli($host_ir, $username_ir, $password_ir, $database_ir);
if ($conn_ir->connect_error) {
    die("Connection to ysmir_ir failed: " . $conn_ir->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['userid'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['userid']; // Logged-in user ID

// Fetch all userids linked to the user from `ysmir_ir`
$stmt = $conn_ir->prepare("SELECT userid FROM user_userid WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$userids = [];
while ($row = $result->fetch_assoc()) {
    $userids[] = $row["userid"];
}
$stmt->close();
$conn_ir->close(); // Close `ysmir_ir` connection

// If user has no linked userids, return an empty response
if (empty($userids)) {
    echo json_encode(["error" => "No userids linked to your account."]);
    exit();
}

// Convert `userids` array into a comma-separated string for SQL
$userid_placeholders = implode(",", array_fill(0, count($userids), "?"));
$types = str_repeat("s", count($userids)); // Generate types for `bind_param`

// Fetch temperature and switch states for all linked userids from `ysmir_main`
$query = "SELECT userid, temp, switch1, switch2, time FROM ysmir_main.temp WHERE userid IN ($userid_placeholders) ORDER BY time DESC LIMIT 50";
$stmt = $conn->prepare($query);

if (!$stmt) {
    echo json_encode(["error" => "Query preparation failed: " . $conn->error]);
    exit();
}

$stmt->bind_param($types, ...$userids);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$stmt->close();
$conn->close(); // Close `ysmir_main` connection

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
