<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes, maximum-scale=5">
    
    <title>Background Image with Side List</title>
    <style>
        ::-webkit-scrollbar{
           width : 2.5 vm;
        }
        ::-webkit-scrollbar-track{
           background-color : green ;
           border-radius : 10em;
        }
        body, html {
             height: 100%;
             overflow-y: auto;
             position: relative; /* Add this */
             overflow-x: auto;
             white-space: nowrap;
        }

        body::before {
            content: '';
            position: fixed; /* Change from absolute to fixed */
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.8);
            z-index: -1; /* Add this to place it behind the content */
         }



        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('background.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
        }
       
        body::before {
           content: '';
           position: absolute;
           top: 0;
           left: 0;
           width: 100%;
           height: 100%;
           background-color: rgba(255, 255, 255, 0.8); /* White overlay with 70% opacity */
        }

        .sidebar ul ul {
          margin-left: 20px;
        }

        .sidebar ul ul li {
        font-size: 0.9em;
        }

        .sidebar {
    width: 250px;
    height: 100vh;
    overflow-y: auto;
    background-color: rgba(0, 0, 0, 0.3);
    position: fixed;
    top: 0;
    left: 0;
    padding: 20px;
    color: white;
    margin-top: 85px;
    font-size: 25px;
    transform: translateX(-100%);
    transition: transform 0.3s ease-in-out;
}

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar li {
            margin-bottom: 10px;
            cursor: pointer;
        }
        #hamburgerMenu {
         position: fixed;
         top: 10px;
         left: 10px;
         font-size: 70px;
         background: none;
         border: none;
         color: rgba(250, 0,0, 0.9);
         cursor: pointer;
         z-index: 1000;
         
         }

         .sidebar {
         transform: translateX(-100%);
         transition: transform 0.3s ease-in-out;
         height: 100vh;
         overflow-y: auto;
         }

         .sidebar.open {
         transform: translateX(0);
         }
         

    </style>
</head>
<body>
    <button id="hamburgerMenu">☰</button>

    <div class="sidebar" id="mySidebar">
        <h2>Side List</h2>
        <ul id="sideList">
           <?php
            $items = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Logout"];
            foreach ($items as $item) {
                echo "<li>$item</li>";
            }
            ?>
        </ul>
    </div>

    
            
    

    <script>
       
       document.addEventListener('touchmove', function(e) {
      // Remove any preventDefault() calls that might block scrolling
       });

       document.getElementById('hamburgerMenu').addEventListener('click', function() {
       document.getElementById('mySidebar').classList.toggle('open');
       });
       document.body.addEventListener('click', function(event) {
       const sidebar = document.getElementById('mySidebar');
       const hamburgerMenu = document.getElementById('hamburgerMenu');
  
       // Check if the click is outside the sidebar and hamburger menu
       if (!sidebar.contains(event.target) && event.target !== hamburgerMenu) {
         sidebar.classList.remove('open');
       }
       });
       document.getElementById('mySidebar').addEventListener('click', function(event) {
       event.stopPropagation();
       });

        // Add sub-items dynamically
        const itemsWithSubItems = {
            "Item 1": ["Sub-item 1.1", "Sub-item 1.2"],
            "Item 2": ["Sub-item 2.1", "Sub-item 2.2"],
            "Item 3": ["Sub-item 3.1"],
        };

        const sideList = document.getElementById('sideList');
        const listItems = sideList.querySelectorAll('li');

        listItems.forEach((li) => {
            const text = li.textContent.trim();

            // Add sub-items if they exist for this item
            if (itemsWithSubItems[text]) {
                const subList = document.createElement('ul');
                itemsWithSubItems[text].forEach((subItem) => {
                    const subLi = document.createElement('li');
                    subLi.textContent = subItem;
                    subList.appendChild(subLi);
                });
                li.appendChild(subList);

                // Toggle visibility of sub-items on click
                li.addEventListener('click', function (e) {
                    e.stopPropagation();
                    const childUl = this.querySelector('ul');
                    if (childUl) {
                        childUl.style.display =
                            childUl.style.display === 'block' ? 'none' : 'block';
                    }
                });
            }

            // Handle logout redirection
            if (text === 'Logout') {
                li.addEventListener('click', function () {
                    window.location.href = 'https://www.ysm01.ir/login.php';
                });
            }
        });
        
    </script>
</body>
</html>

