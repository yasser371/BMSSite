<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: login.php');
    exit();
}

$userid = $_SESSION['userid'];
$username = $_SESSION['username'];

$servername = "localhost";
$db_username = "ysmir_ir";
$db_password = "7S2h%}=w,[M+"; // your database password
$dbname = "ysmir_ir";

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user-specific data
$stmt = $conn->prepare("SELECT * FROM user_data WHERE user_id = ?");
$stmt->bind_param("i", $userid);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();

$stmt->close();
$conn->close();

function update($id, $state, $userid) {
    global $servername, $db_username, $db_password, $dbname;
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE outputs SET state=? WHERE id=? AND user_id=?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("iii", $state, $id, $userid);
    if (!$stmt->execute()) {
        die("Error executing statement: " . $stmt->error);
    }

    echo "Updated successfully";
    $stmt->close();
    $conn->close();
}

function getall($userid) {
    global $servername, $db_username, $db_password, $dbname;
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT id, name, gpio, state FROM outputs WHERE user_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userid);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $stmt->close();
    $conn->close();
    
    return $result;
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $action = $_GET["action"];
    if ($action == "state") {
        $result = getall($userid);
        $pins = [];
        while ($row = $result->fetch_assoc()) {
            $pins[$row["gpio"]] = $row["state"];
        }
        echo json_encode($pins);
    }
    if ($action == "output_update") {
        $id = $_GET['id'];
        $state = $_GET['state'];
        update($id, $state, $userid);
    }
    if ($action == "dele") {
        $id = $_GET['id'];
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);
        $sql = "DELETE FROM outputs WHERE id=? AND user_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $id, $userid);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }
}

$result = getall($userid);
$html_buttons = NULL;
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $button_checked = $row["state"] == '1' ? "checked" : "";
        $html_buttons .= '
        <div class="gpio-container">
            <h3>' . htmlspecialchars($row["name"]) . ' GPIO: ' . htmlspecialchars($row["gpio"]) . ' <a class="delete" onclick="delt(this)" id="' . htmlspecialchars($row["id"]) . '">X</a></h3>
            <label class="switch">
                <input type="checkbox" onchange="update(this)" id="' . htmlspecialchars($row["id"]) . '" ' . $button_checked . '>
                <span class="slider"></span>
            </label>
            <img class="led-icon" id="led-' . htmlspecialchars($row["id"]) . '" src="' . ($button_checked ? 'led_on.png' : 'led_off.png') . '" alt="LED">
        </div>
        ';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        .dashboard-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
        }
        .dashboard-container h2 {
            margin-bottom: 20px;
            color: #333;
            font-weight: 500;
        }
        .dashboard-container p {
            color: #555;
            margin-bottom: 15px;
        }
        .panel {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
            margin-top: 20px;
        }
        .panel h3 {
            margin-bottom: 20px;
            color: #333;
            font-weight: 500;
        }
        .gpio-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .delete {
            color: red;
            cursor: pointer;
        }
        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        input:checked + .slider {
            background-color: #2196F3;
        }
        input:checked + .slider:before {
            transform: translateX(26px);
        }
        .led-icon {
            width: 30px;
            height: 30px;
        }
        .logout-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #ff4b5c;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.7s ease;
        }
        .logout-btn:hover {
            background-color: #e0434d;
        }
    </style>
</head>
<body>

    <div class="dashboard-container">
        <h2>Welcome, <?php echo htmlspecialchars($username); ?></h2>
        <?php if ($user_data): ?>
            <p>Your user-specific data:</p>
            <!-- Display user-specific data -->
            <p>Data field 1: <?php echo htmlspecialchars($user_data['field1']); ?></p>
            <p>Data field 2: <?php echo htmlspecialchars($user_data['field2']); ?></p>
            <!-- Add more fields as necessary -->
        <?php else: ?>
            <p>No data available for your account.</p>
        <?php endif; ?>
        <form method="post" action="logout.php">
            <input class="logout-btn" type="submit" value="Logout">
        </form>
    </div>

    <div class='panel'>
        <?php echo $html_buttons; ?>
    </div>
    
    <script>
        function update(element){
            var xhr = new XMLHttpRequest();
            console.log("Updating GPIO:", element.id, "State:", element.checked);
            var ledIcon = document.getElementById("led-" + element.id);
            if (element.checked){
                xhr.open("GET", "<?php echo $_SERVER['PHP_SELF']; ?>?action=output_update&id="+element.id+"&state=1", true);
                ledIcon.src = "led_on.png"; // Change to LED on image
            } else {
               xhr.open("GET", "<?php echo $_SERVER['PHP_SELF']; ?>?action=output_update&id="+element.id+"&state=0", true);
               ledIcon.src = "led_off.png"; // Change to LED off image
            }
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    console.log("Update response:", xhr.responseText);
                }
            };
            xhr.send();
        }

        function delt(element){
            var result = confirm("Are you sure you want to delete?");
            if(result){
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "<?php echo $_SERVER['PHP_SELF']; ?>?action=dele&id="+element.id, true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        console.log(xhr.responseText); // Debugging response
                        alert("Deleted successfully");
                        setTimeout(function(){
                            window.location.reload();
                        }, 500); // Reload after 500ms
                    }
                };
                xhr.send();
            }
        }
    </script>
</body>
</html>
