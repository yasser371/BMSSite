<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "ysmir_ir";
$password = "7S2h%}=w,[M+";
$dbname = "ysmir_ir";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userid = $_SESSION['userid'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = trim($_POST['new_username']);
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);

    // Update username and password
    $stmt = $conn->prepare("UPDATE users SET name = ?, password = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_username, $new_password, $userid);

    if ($stmt->execute()) {
        $_SESSION['name'] = $new_username;
        header("Location: test.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>
