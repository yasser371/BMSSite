<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$dbname = "ysmir_main";
$username = "ysmir_ysm";
$password = "Y13601981s";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$temp = NULL;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["dama"])) {
        $temp = $_POST["dama"];
        echo "Received Temperature: " . $temp;  // Debugging output
    } else {
        echo "No 'dama' value received!";
    }
}

if ($temp != NULL) {
    $sql = "INSERT INTO temp(temp) VALUES('$temp')";
    if ($conn->query($sql) === TRUE) {
        echo "✅ Data inserted successfully";
    } else {
        echo "❌ Error: " . $conn->error;
    }
}

?>

<html>
    <style>
        .temp{
            background:#444;
            max-width:300px;
            color:#fff;
            padding:10px;
            border-radius:10px;
        }
        .time{
            background:#ddd;
            color:#444;
        }
    </style>
    
    <center>
        <h1>
        سیستم گزارش دما
    </h1>
    <h2>
        دوره اینترنت اشیا حرفه ای
    </h2>
        <?php
            $sql = "SELECT * FROM temp ORDER BY id DESC LIMIT 10";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc()){
                $dama = $row["temp"];
                $zaman = $row["time"];
                $zaman = date("Y-m-d H:i:s",strtotime("$zaman - 1 hour"));
                echo "<div class='temp'>" . $dama . "C<div class='time'>" . $zaman . "</div></div><br>";
            }
        ?>
    </center>
</html>