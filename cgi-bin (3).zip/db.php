<?php
$host = "localhost";
$username = "ysmir_ysm";
$password = "Y13601981s";
$database = "ysmir_main";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
