<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: login.php');
    exit();
}

// Page content
?>
<!DOCTYPE html>
<html>
<head>
    <title>Protected Page</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Protected Content</h1>
</body>
</html>
