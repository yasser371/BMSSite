<?php
header("Content-Type: application/json");
require_once("db.php");

// First attempt: Read JSON normally
$json = file_get_contents("php://input");

// If empty, try $_POST fallback
if (empty($json)) {
    $json = json_encode($_POST);
}

// Debugging: Log received JSON
file_put_contents("debug_log.txt", "Raw JSON: " . $json . PHP_EOL, FILE_APPEND);

$data = json_decode($json, true);

// Check if JSON is received
if (!$data) {
    echo json_encode(["error" => "No JSON received", "raw" => $json]);
    exit;
}

// Validate required fields
if (!isset($data["userid"], $data["mac"], $data["switch1"], $data["switch2"], $data["temp"])) {
    echo json_encode(["error" => "Missing parameters"]);
    exit;
}

$userid = $data["userid"];
$mac = $data["mac"];
$switch1 = $data["switch1"];
$switch2 = $data["switch2"];
$temp = $data["temp"];

// Save data into `temp` table
$stmt = $conn->prepare("INSERT INTO temp (userid, mac, switch1, switch2, temp) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssdd", $userid, $mac, $switch1, $switch2, $temp);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "switch1" => $switch1, "switch2" => $switch2, "temp" => $temp]);
} else {
    echo json_encode(["error" => "Database error"]);
}

$stmt->close();
$conn->close();
?>
