<?php
$passwords = [
    'a1234a', 'b1234b', 'c1234c', 'd1234d', 'e1234e',
    'f1234f', 'g1234g', 'h1234h', 'l1234l', 'k1234k'
];

foreach ($passwords as $password) {
    echo "Password: " . $password . " - Hash: " . password_hash($password, PASSWORD_DEFAULT) . "<br>";
}
?>
