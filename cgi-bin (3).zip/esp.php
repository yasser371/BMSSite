
<?php
$servername = "localhost";
$dbname = "ysmir_ir";
$username = "ysmir_ir";
$password = "7S2h%}=w,[M+";
$conn = new mysqli($servername,$username,$password,$dbname);
$pd = 'salam';
if ($conn->connect_error){
    die("Connection Faild:" . $conn->connect_error);
}

function update($id,$state){
    global $servername , $username , $password , $dbname;
    $conn = new mysqli($servername,$username,$password,$dbname);
    $sql = "UPDATE outputs SET state='" .$state ."'WHERE id ='" .$id."'";
    $conn->query($sql);
    $conn->close();
}
function getall(){
    global $servername , $username , $password , $dbname;
    $conn = new mysqli($servername,$username,$password,$dbname);
    $sql = "SELECT id,name,gpio,state FROM outputs";
    $result = $conn->query($sql);
    return $result;
    $conn->close();
}


if($_SERVER["REQUEST_METHOD"] == "GET"){
    $action = $_GET["action"];
    if($action == "state"){
        $result = getall();
        while($row = $result->fetch_assoc()){
            $pins[$row["gpio"]] = $row["state"];
        }
        echo json_encode($pins);
    }
    if($action == "output_update"){
        $id = $_GET['id'];
        $state = $_GET['state'];
        $passwor = $_GET['pass'];
        if ($passwor == $pd){
            update($id,$state);
        }
    }
    if($action =="dele"){
        $id = $_GET['id'];
        $pass = $_GET['pass'];
        if($pass == $pd){
            $sql = "DELETE FROM outputs WHERE id = '".$id."'";
            $conn->query($sql);
            $conn->close();
        }
    }
}
if ($_SERVER["REQUEST_METHOD"] == 'POST'){
    $gpio = $_POST['gpio'];
    $name = $_POST['name'];
    $sql = "INSERT INTO outputs(name,gpio) VALUES ('".$name."','".$gpio."');";
    $conn->query($sql);
    $conn->close();
}


$result = getall();
$html_buttons = NULL;
if ($result){
    while($row = $result->fetch_assoc()){
        if($row["state"] == '1'){
            $button_checked = "checked";
        }
        else{
            $button_checked = "";
        }
        $html_buttons .='
        <h3>' .$row["name"].' GPIO:' . $row["gpio"].' <a class="delete" onclick="delt(this)" id="'.$row["id"].'">X</a></h3>
        <label class="switch">
        <input type="checkbox" onchange="update(this)" id="'.$row["id"].'"'. $button_checked.'>
        <span class="slider"></span>
        </label>
        ';
    }
}



?>
<html>
    <head>
      <link rel='stylesheet' type='text/css' href='style.css'>  
      <title>کنترل خانه اینترنتی</title>
    </head>
    <body>
        <h1>کنترل پایه اینترنتی</h1>
        <div class='panel'>
            <input class="inp" type="password" placeholder="رمز خود را وارد کنید" id="password">
            <?php echo $html_buttons; ?>
        </div>
        <div class="panel">
            <h3>افزودن پایه</h3>
        <form method="post" action="<?php $_SERVER["PHP_SELF"];?>">
            <input class="inp" type="text" name="name" placeholder="نام را وارد کنید"><br>
            <input class="inp" type="number" name="gpio" placeholder="شماره GPIO را وارد کنید"><br>
            <input class="sub" type="submit" name="submit" value="افزودن">
            
        </form>


        </div>
        <script>
            function update(element){
                var xhr = new XMLHttpRequest();
                var password = document.getElementById("password").value;
            if (element.checked){
                xhr.open("GET","esp.php?action=output_update&id="+element.id+"&state=1&pass="+password,true);
            }
            else{
               xhr.open("GET","esp.php?action=output_update&id="+element.id+"&state=0&pass="+password,true) ;
            }
            xhr.send();
            }
            function delt(element){
                var result= confirm("از انجام اینکار اطمینان دارید؟");
                if(result){
                    var password = document.getElementById("password").value;
                    var xhr = new XMLHttpRequest();
                    xhr.open("GET","esp.php?action=dele&id="+element.id+"&pass="+password,true);
                    xhr.send();
                    alert("حذف شد");
                    setTimeout(function(){
                        window.location.reload();
                    });
                }
            }
        </script>
    </body>
    
    
</html>