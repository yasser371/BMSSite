document.addEventListener("DOMContentLoaded", function () {
    const addUserIdButton = document.getElementById("addUserIdButton");
    const removeUserIdButton = document.getElementById("removeUserIdButton");
    const userIdList = document.getElementById("userIdList");
    const userIdInput = document.getElementById("userIdInput");
    const temperatureDataContainer = document.getElementById("temperatureData");

    // Fetch linked userids on page load
    fetchUserIds();

    // Add new userid
    addUserIdButton.addEventListener("click", function () {
        const userId = userIdInput.value.trim();
        if (userId.length >= 12) {
            fetch("setting.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `new_userid=${userId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("UserID added successfully.");
                    fetchUserIds();
                } else {
                    alert(data.error || "Error adding UserID.");
                }
            });
        } else {
            alert("UserID must be at least 12 digits.");
        }
    });

    // Remove selected userid
    removeUserIdButton.addEventListener("click", function () {
        const userIdToRemove = userIdInput.value.trim();
        if (userIdToRemove) {
            fetch("setting.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `remove_userid=${userIdToRemove}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("UserID removed successfully.");
                    fetchUserIds();
                } else {
                    alert(data.error || "Error removing UserID.");
                }
            });
        }
    });

    // Fetch all userids linked to the logged-in user
    function fetchUserIds() {
        fetch("setting.php")
            .then(response => response.json())
            .then(data => {
                userIdList.innerHTML = "";
                if (data.userids && data.userids.length > 0) {
                    data.userids.forEach(userid => {
                        const li = document.createElement("li");
                        li.textContent = `UserID: ${userid}`;
                        userIdList.appendChild(li);
                    });
                    fetchTemperatureData(data.userids);
                } else {
                    userIdList.innerHTML = "No UserIDs linked to your account.";
                }
            });
    }

    // Fetch temperature and switch data for all linked userids
    function fetchTemperatureData(userids) {
        fetch("test.php")
            .then(response => response.json())
            .then(data => {
                temperatureDataContainer.innerHTML = "";
                if (data.length > 0) {
                    data.forEach(record => {
                        const recordElement = document.createElement("div");
                        recordElement.classList.add("temperature-record");
                        recordElement.innerHTML = `
                            <strong>UserID:</strong> ${record.userid}<br>
                            <strong>Temperature:</strong> ${record.temp} °C<br>
                            <strong>Switch 1:</strong> ${record.switch1}<br>
                            <strong>Switch 2:</strong> ${record.switch2}<br>
                            <strong>Time:</strong> ${record.time}<br>
                            <hr>
                        `;
                        temperatureDataContainer.appendChild(recordElement);
                    });
                } else {
                    temperatureDataContainer.innerHTML = "No temperature data available.";
                }
            });
    }
});
