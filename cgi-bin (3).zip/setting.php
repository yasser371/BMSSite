<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['userid'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['userid']; // Logged-in user ID

// Fetch all userids linked to the user from ysmir_ir
$stmt = $conn->prepare("SELECT userid FROM ysmir_ir.user_userid WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$userids = [];
while ($row = $result->fetch_assoc()) {
    $userids[] = $row["userid"];
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Settings</title>
    <script src="script.js" defer></script>
</head>
<body>

    <div>
        <h2>Manage Your UserIDs</h2>
        <label for="userIdInput">Enter UserID (12+ digits):</label>
        <input type="text" id="userIdInput" placeholder="Enter new UserID">
        <button id="addUserIdButton">Add UserID</button>
        <button id="removeUserIdButton">Remove UserID</button>

        <h3>Linked UserIDs:</h3>
        <ul id="userIdList">
            <?php
            // Display the linked userids for this user
            foreach ($userids as $userid) {
                echo "<li>UserID: $userid</li>";
            }
            ?>
        </ul>
    </div>

    <div id="temperatureData">
        <!-- Temperature and switch data will be shown here -->
    </div>

</body>
</html>
